<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Recognition extends Model
{
    //
}
