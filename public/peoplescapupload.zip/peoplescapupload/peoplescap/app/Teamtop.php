<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teamtop extends Model
{
    //
}
