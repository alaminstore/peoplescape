<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cvform extends Model
{
    //
}
