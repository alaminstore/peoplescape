<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Servicehead extends Model
{
    //
}
