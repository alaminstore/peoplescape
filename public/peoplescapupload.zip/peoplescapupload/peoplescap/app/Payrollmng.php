<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payrollmng extends Model
{
    //
}
