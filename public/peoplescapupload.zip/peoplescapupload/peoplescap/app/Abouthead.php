<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Abouthead extends Model
{
    //
}
