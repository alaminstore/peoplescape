<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aboutcall2 extends Model
{
    //
}
