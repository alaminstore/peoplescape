<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Careercat;
use App\Career;
use App\Careerhead;
class CareerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $data = [];
        $data['cat'] = Careercat::all();
        $data['job'] = Career::all();
        $data['careerhead'] = Careerhead::find(1);
        return view('Backend.career.career',compact('data'));
    }
    public function careerheadupdate(Request $request){
        $id = $request->id;
        $careerHead = Careerhead::find($id);
        if($request->file('image')){
            $find_image = Careerhead::find($id);
            $old_img = $find_image->image;
            if($old_img){
                unlink($old_img);
            }
        $image = $request->file('image');
        $new_name = time() . '.' . $image->getClientOriginalExtension();
        $image->move(public_path('psimage'), $new_name);
        $careerHead = Careerhead::find($id);
        $careerHead->title = $request->title;
        $careerHead->image = 'psimage/'.$new_name;
        $careerHead->save();
        return response()->json($careerHead);
        }else{
        $careerHead = Careerhead::find($request->id);
        $careerHead->title = $request->title;
        $careerHead->save();
        return response()->json($careerHead);
        }
    }
    public function careercatstore(Request $request){
        $careerCat = new Careercat();
        $careerCat->title = $request->title;
        $careerCat->save();
        return response()->json($careerCat);
    }
    
    public function careercatedit(Request $request){
        $id = $request->id;
        $careerCat = Careercat::find($id);
        return response()->json($careerCat);
    }
    public function careercatupdate(Request $request){
        $id = $request->id;
        $careerCat = Careercat::find($id);
        $careerCat->title = $request->title;
        $careerCat->save();
        return response()->json($careerCat);
    }
    public function careercatdelete(Request $request){
        $id = $request->id;
        $careerCat = Careercat::find($id);
        $careerCat->delete();
        return response()->json('deleted');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
    
        $career = new Career();
        $career->title = $request->title;
        $career->company = $request->company;
        $career->experience = $request->experience;
        $career->vacancy = $request->vacancy;
        $career->education = $request->education;
        $career->deadline = $request->deadline;
        $career->location = $request->location;
        $career->salary = $request->salary;
        $career->catid = $request->catid;
        $career->posteddate = date('d/m/Y');
        $career->topdescription = $request->topdescription;
        $career->howtoapply = $request->howtoapply;
        $career->responsibilitiestext = $request->responsibilitiestext;
        if($request->program){
            $career->responsibilitiespoint = json_encode($request->program);
        }
        if($request->qualification){
            $career->qualification = json_encode($request->qualification);
        }
         $career->save();
         return response()->json($career);
    }
    public function careeredit(Request $request){
     $id = $request->id;
     $data['careerbyid']  = Career::find($id);
     $data['cat'] = Careercat::all();
     return view('Backend.career.editcareer',compact('data'));

    }
    public function careerupdate(Request $request){

        $career = Career::find($request->id);
        $career->title = $request->title;
        $career->company = $request->company;
        $career->experience = $request->experience;
        $career->vacancy = $request->vacancy;
        $career->education = $request->education;
        $career->deadline = $request->deadline;
        $career->location = $request->location;
        $career->salary = $request->salary;
        $career->catid = $request->catid;
        $career->topdescription = $request->topdescription;
        $career->howtoapply = $request->howtoapply;
        $career->responsibilitiestext = $request->responsibilitiestext;
        if($request->program){
            $career->responsibilitiespoint = json_encode($request->program);
        }
        if($request->qualification){
            $career->qualification = json_encode($request->qualification);
        }
        $career->save();
        return redirect()->route('careerop.index');
        // $findPrevious->delete();
        // $data = $request->all();
        // return $data;
    }
    public function careerdelete(Request $request){
     $id = $request->id;
     $careerByid  = Career::find($id);
     $careerByid->delete();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
