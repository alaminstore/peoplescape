<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Slider;
use App\Sliderbtm;
use App\Servetop;
use App\Allservices;
use App\Locationtop;
use App\Alllocations;
use App\Hcall;
use App\Teamtop;
use App\Teammembers;
use App\Monialtop;
use App\Testimonials;
use App\Counterpart;
use App\Servicehead;
use App\Cvform;
use App\User;
class PeoplesscapeHomeController extends Controller
{
    public function index(){
        $data = [];
        $data['slider']= Slider::orderBy('id','desc')->get();
        $data['sliderbtm']= Sliderbtm::find(1);
        $data['servtop']= Servetop::find(1);
        $data['allservice']= Allservices::all();
        $data['locationtop']= Locationtop::find(1);
        $data['alllocations']= Alllocations::all();
        $data['hcall']= Hcall::find(1);
        $data['teamtop']= Teamtop::find(1);
        $data['teammembers']= Teammembers::all();
        $data['monialtop'] = Monialtop::find(1);
        $data['testimonial'] = Testimonials::all();
        $data['counterpart'] = Counterpart::find(1);
       return view('Frontend.home',compact('data'));
    }

    public function cvform(){
        $data=[]; 
        $data['servicehead'] = Servicehead::find(1);
        return view('Frontend.cvcreate',compact('data'));
    }
    public function cvformstore(Request $request){
        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->mobile = $request->mobile;
        $user->gender = $request->gender;
        $user->status = "user";
        $user->password = bcrypt($request->password);
        $user->save();

        $image = $request->file('cv');
        $new_name = rand() . '.' . $image->getClientOriginalExtension();
        $image->move(public_path('careerfile'), $new_name);
        $cvform  = new Cvform();
        $cvform->userid = $user->id;
        $cvform->name = $request->name;
        $cvform->birthdate = $request->birthdate;
        $cvform->paddress = $request->paddress;
        $cvform->haddress = $request->haddress;
        $cvform->mobile = $request->mobile;
        $cvform->email = $request->email;
        $cvform->interest = $request->interest;
        $cvform->cv ='careerfile/'.$new_name;

        if($request->academic){
            $cvform->academic = json_encode($request->academic);
        }
        if($request->experience){
            $cvform->experience =json_encode($request->experience);
        }
        if($request->project){
            $cvform->project =json_encode($request->project);
        }
        $cvform->save();

        
        $notification = array(
            'message' => 'Success! You can Login Now', 
            'alert-type' => 'success'
        );
        
        return redirect()->back()->with($notification);

    }
    
}
