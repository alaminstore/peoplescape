<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Careercat;
use App\Career;
use App\Careerhead;
use App\Aboutcall2;
use DB;
class CareerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $jobDetail = DB::table('careers')
                     ->select('careers.*','careercats.title as catname')
                     ->select('careers.*','careercats.title as catname')
                     ->leftJoin('careercats','careers.catid','=','careercats.id')
                     ->paginate(2);
        $data['careerhead'] = Careerhead::find(1);
        return view('Frontend.career',\compact('jobDetail','data'));
    }
    public function careerdetails(Request $request){
     $id = $request->id;
     $careerByid = DB::table('careers')
                ->select('careers.*','careercats.title as catname')
                ->select('careers.*','careercats.title as catname','careercats.id as catid')
                ->leftJoin('careercats','careers.catid','=','careercats.id')
                ->where('careers.id','=',$id)
                ->first();
     $catid = $careerByid->catid;
    $categoryWisecareer = DB::table('careers')
                        ->select('careers.*','careercats.title as catname')
                        ->select('careers.*','careercats.title as catname')
                        ->leftJoin('careercats','careers.catid','=','careercats.id')
                        ->where('careers.catid','=',$catid)
                        ->where('careers.id','!=',$id)
                        ->get();
     $callact= Aboutcall2::find(1);
     return view('Frontend.singlecareer',compact('careerByid','callact','categoryWisecareer'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
