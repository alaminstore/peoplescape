<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aboutcall1 extends Model
{
    //
}
