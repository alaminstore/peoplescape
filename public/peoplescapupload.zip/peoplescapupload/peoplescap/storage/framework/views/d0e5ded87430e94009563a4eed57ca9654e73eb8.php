<?php $__env->startSection('srv','active'); ?>
<?php $__env->startSection('title', 'Peoplesscap | Services '); ?>
<?php $__env->startSection('frntcontent'); ?>
<section class="page-banner-area" style="background: url(<?php echo e($data['servicehead']->image); ?>); background-repeat: no-repeat; background-position: center; background-size: cover; background-attachment: fixed;">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h2 class="page-banner-title"><?php echo e($data['servicehead']->title); ?></h2>
            </div>
        </div>
    </div>
</section>

<!-- Services Details Area START -->
<section class="services-details-area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h2 class="theme-title"><?php echo e($data['servicetop']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
                <p class="theme-para"><?php echo e($data['servicetop']->description); ?> </p>
            </div>
            
            <div class="col-sm-12 all-s-details">
                <div id="head" class="common-single-s-details">
                    <div class="single-s-details">
                        <div class="single-s-slider-wrapper">
                            <div class="single-s-slider">
                                <!-- Wrapper for slides -->
                                <figure class="item">
                                    <img alt="Services" src="<?php echo e(url($data['hunting']->image)); ?>">
                                </figure>
                            </div>
                        </div>
                        <div class="single-s-content">
                            <h4><?php echo e($data['hunting']->title); ?></h4>
                            <p><?php echo e($data['hunting']->description); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div id="manpower" class="common-single-s-details">
                    <div class="single-s-details">
                        <div class="single-s-slider-wrapper">
                            <div class="single-s-slider">
                               
                                <figure class="item">
                                    <img alt="Services" src="<?php echo e(url($data['manpower']->image)); ?>">
                                </figure>
                            </div>
                        </div>
                        <div class="single-s-content">
                            <h4><?php echo e($data['manpower']->title); ?></h4>
                            <p><?php echo e($data['manpower']->description); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div id="payroll" class="common-single-s-details">
                    <div class="single-s-details">
                        <div class="single-s-slider-wrapper">
                            <div class="single-s-slider">
                               
                                <figure class="item">
                                    <img alt="Services" src="<?php echo e(url($data['payroll']->image)); ?>">
                                </figure>
                            </div>
                        </div>
                        <div class="single-s-content">
                                <h4><?php echo e($data['payroll']->title); ?></h4>
                                <p><?php echo e($data['payroll']->description); ?>

                                </p>
                        </div>
                    </div>
                </div>
                <div id="medical" class="common-single-s-details">
                    <div class="single-s-details">
                        <div class="single-s-slider-wrapper">
                            <div class="single-s-slider">
                         
                                <figure class="item">
                                    <img alt="Services" src="<?php echo e(url($data['medical']->image)); ?>">
                                </figure>
                            </div>
                        </div>
                        <div class="single-s-content">
                                <h4><?php echo e($data['medical']->title); ?></h4>
                                <p><?php echo e($data['medical']->description); ?>

                                </p>
                        </div>
                    </div>
                </div>
                <div id="assessment" class="common-single-s-details">
                    <div class="single-s-details">
                        <div class="single-s-slider-wrapper">
                            <div class="single-s-slider">
                             
                                <figure class="item">
                                    <img alt="Services" src="<?php echo e(url($data['asses']->image)); ?>">
                                </figure>
                            </div>
                        </div>
                        <div class="single-s-content">
                                <h4><?php echo e($data['asses']->title); ?></h4>
                                <p><?php echo e($data['asses']->description); ?>

                                </p>
                        </div>
                    </div>
                </div>
                <div id="recruitment" class="common-single-s-details">
                    <div class="single-s-details">
                        <div class="single-s-slider-wrapper">
                            <div class="single-s-slider">

                                <figure class="item">
                                    <img alt="Services" src="<?php echo e(url($data['recruit']->image)); ?>">
                                </figure>
                            </div>
                        </div>
                        <div class="single-s-content">
                                <h4><?php echo e($data['recruit']->title); ?></h4>
                                <p><?php echo e($data['recruit']->description); ?>

                                </p>
                        </div>
                    </div>
                </div>
                <div id="training" class="common-single-s-details">
                    <div class="single-s-details">
                        <div class="single-s-slider-wrapper">
                            <div class="single-s-slider">
                            
                                <figure class="item">
                                    <img alt="Services" src="<?php echo e(url($data['training']->image)); ?>">
                                </figure>
                            </div>
                        </div>
                        <div class="single-s-content">
                                <h4><?php echo e($data['training']->title); ?></h4>
                                <p><?php echo e($data['training']->description); ?>

                                </p>
                        </div>
                    </div>
                </div>
                <!-- <div id="service8" class="common-single-s-details">
                    <div class="single-s-details">
                        <div class="single-s-slider-wrapper">
                            <div class="single-s-slider">
                               
                                <figure class="item">
                                    <img alt="Services" src="img/services-img/services1.jpg">
                                </figure>
                            </div>
                        </div>
                        <div class="single-s-content">
                            <h4>Health Screening</h4>
                            <p>With true Events expertise on board, we work with meticulous and unyielding focus on landing the kind of event folks will remember for days to come. From conception to execution, we are here to ensure your event runs smoothly without any fumbles.<br><br> We are big on spectacle but never lose track of the details.<br> <br> We are big on spectacle but never lose track of the details. We are big on spectacle but never lose track of the details.
                            </p>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</section>
<!-- Services Details Area END -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.frontmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Frontend/service.blade.php ENDPATH**/ ?>