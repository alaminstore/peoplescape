<?php $__env->startSection('title', 'Pescapople | dashboard'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
        <div class="box box-default">
             <div class="box-header with-border">
               <h3 class="box-title">Dashboard</h3>
                  <div class="box-tools pull-right">
                 <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                 <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
               </div>
             </div>
            
             <div class="box-body">
               <div class="row"> 
                   <div class="welcome-card">
                     
                      <h4 style="padding-left:10px;">Welcome <?php echo e(Auth::user()->name); ?></h4>
                   </div>
               </div>
             </div>
            
           </div>
           <script>
              <?php if(Session::has('message')): ?>
                    toastr.options = {
                                    "debug": false,
                                    "positionClass": "toast-bottom-right",
                                    "onclick": null,
                                    "fadeIn": 300,
                                    "fadeOut": 1000,
                                    "timeOut": 5000,
                                    "extendedTimeOut": 1000
                                };
                    toastr.success("<?php echo e(Session::get('message')); ?>");
                <?php endif; ?>
             </script>
         </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.backendmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Backend/welcome.blade.php ENDPATH**/ ?>