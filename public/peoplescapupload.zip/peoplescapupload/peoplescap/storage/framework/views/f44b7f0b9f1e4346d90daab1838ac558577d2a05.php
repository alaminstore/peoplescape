<?php $__env->startSection('rg','active'); ?>
<?php $__env->startSection('title', 'Peoplesscap | Recognitions '); ?>
<?php $__env->startSection('frntcontent'); ?>
<section class="page-banner-area" style="background: url(<?php echo e($data['recoghead']->image); ?>); background-repeat: no-repeat; background-position: center; background-size: cover; background-attachment: fixed;">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <h2 class="page-banner-title"><?php echo e($data['recoghead']->title); ?></h2>
        </div>
      </div>
    </div>
  </section>
  
  <section class="recognitions-page-area">
      <div class="container">
          <div class="row">
              <!--Start Single Recognitions Page Area-->
              <?php $__currentLoopData = $data['recog']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-12">
                  <div class="recognitions-single-box">
                      <img src="<?php echo e(url($recog->image)); ?>" alt="Recognitions">
  
                      <div class="recognitions-content-box">
                          <h4><?php echo e($recog->title); ?></h4>
                          <p><?php echo e($recog->description); ?>

                          </p>
                      </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <!--End Single Recognitions Page Area-->
              <!--Start Single Recognitions Page Area-->
              
              <!--End Single Recognitions Page Area-->
              <!--Start Single Recognitions Page Area-->
              
              <!--End Single Recognitions Page Area-->
              <!--Start Single Recognitions Page Area-->
              
              <!--End Single Recognitions Page Area-->
              <!--Start Single Recognitions Page Area-->
              
              <!--End Single Recognitions Page Area-->
          </div>
      </div>
  </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.frontmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Frontend/recognition.blade.php ENDPATH**/ ?>