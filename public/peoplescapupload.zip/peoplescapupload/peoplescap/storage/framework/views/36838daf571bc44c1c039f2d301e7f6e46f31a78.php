<?php $__env->startSection('application-active','active'); ?>
<?php $__env->startSection('title', 'Peoplescape | Application Lists'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-info">
          <div class="box-header">
            <h3 class="box-title">Application  List</h3>
             <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
              </div>
             </div>
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr>
               <th width="5%">S.I</th>
                <th width="30%">Name</th>
                <th width="30%">Email</th> 
                <th width="30%">MobileNO</th>
                
              </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $cv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                   <td><?php echo e($loop->index + 1); ?></td>
                  <td><a href="<?php echo e(route('application.show',['id'=>$val->id])); ?>" style="cursor:pointer"><?php echo e($val->name); ?></a></td>
                  <td><?php echo e($val->email); ?></td>
                  <td><?php echo e($val->mobile); ?></td>
                  
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.backendmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Backend/application/application.blade.php ENDPATH**/ ?>