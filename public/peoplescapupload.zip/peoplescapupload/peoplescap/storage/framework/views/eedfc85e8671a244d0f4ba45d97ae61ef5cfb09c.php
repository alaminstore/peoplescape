<?php $__env->startSection('abt','active'); ?>
<?php $__env->startSection('title', 'Peoplesscap | About-us '); ?>
<?php $__env->startSection('frntcontent'); ?>
<section class="page-banner-area" style="background: url(<?php echo e($data['abouthead']->image); ?>); background-repeat: no-repeat; background-position: center; background-size: cover; background-attachment: fixed;">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <h2 class="page-banner-title"><?php echo e($data['abouthead']->title); ?></h2>
        </div>
      </div>
    </div>
  </section>
  <section class="mission-vision-area">
      <div class="container-fluid">
          <div class="row">
              
              <div class="col-sm-6 padding-zero">
                  <div class="mission-vision-box only-vision">
                      <h2><?php echo e($data['vision']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
  
                      <p><?php echo e($data['vision']->description); ?>

                      </p>
                  </div>
              </div>
              <div class="col-sm-6 padding-zero">
                  <div class="mission-vision-box only-mission">
                      <h2><?php echo e($data['mission']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
  
                      <p> <?php echo e($data['mission']->description); ?>

                      </p>
                  </div>
              </div>
          </div>
      </div>
  </section>
  
  <section class="introduction-area">
      <div class="container">
          <div class="row">
              <div class="col-sm-6">
                  <div class="left-box" style="background: url(<?php echo e($data['choose']->image); ?>)">
                  </div>
              </div>
              <div class="col-sm-6">
                  <div class="right-box">
                      <h2><?php echo e($data['choose']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
  
                      <p>
                          <?php echo e($data['choose']->description); ?>

                      </p>
                  </div>
              </div>
          </div>
      </div>
  </section>
  
  <!--<section class="call-to-action-area">-->
  <!--    <div class="container">-->
  <!--        <div class="row">-->
  <!--            <div class="col-sm-12">-->
  <!--                <div class="call-to-content">-->
  <!--                    <h2><?php echo e($data['call1']->description); ?></h2>-->
  <!--                    <a href="#" class="common-button">Learn More</a>-->
  <!--                </div>-->
  <!--            </div>-->
  <!--        </div>-->
  <!--    </div>-->
  <!--</section>-->
  
 
  
  
  
  <section class="advantage-area success-story-area">
      <div class="container-fluid">
          <div class="row">
              <div class="col-sm-6 padding-zero">
                  <div class="advantage-img-box" style="background: url(<?php echo e($data['success']->image); ?>);background-repeat: no-repeat; background-size: cover;">
                  </div>
              </div>
              <div class="col-sm-6 padding-zero">
                  <div class="advantage-content-box">
                      <h2><?php echo e($data['success']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
                      <?php
                      $description = json_decode($data['success']->description);
                      
                      ?>
                      <?php $__currentLoopData = $description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $success): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="single-advantage-list success-story-point">
                          <div class="icon-part">
                              <i class="far fa-dot-circle"></i>
                          </div>
                          <div class="point-content">
                              <h5><?php echo e($success->ptitle); ?></h5>
                              <p><?php echo e($success->description); ?>

                              </p>
                          </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
                 </div>
              </div>
          </div>
      </div>
  </section>
  
  <!--<section class="call-to-action-area">-->
  <!--    <div class="container">-->
  <!--        <div class="row">-->
  <!--            <div class="col-sm-12">-->
  <!--                <div class="call-to-content">-->
  
  <!--                    <a href="#" class="common-button">Learn More</a>-->
  <!--                </div>-->
  <!--            </div>-->
  <!--        </div>-->
  <!--    </div>-->
  <!--</section>-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.frontmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Frontend/aboutus.blade.php ENDPATH**/ ?>