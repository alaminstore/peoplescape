<?php $__env->startSection('hm','active'); ?>
<?php $__env->startSection('title', 'Peoplesscap | Home '); ?>
<?php $__env->startSection('frntcontent'); ?>
<!--<section class="slider-area text-center carousel slide" id="carouselExampleIndicators" data-ride="carousel">-->
    <section class="slider-area carousel slide" id="carouselExampleIndicators" data-ride="">
        <ol class="carousel-indicators">
            <?php $__currentLoopData = $data['slider']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($loop->index); ?>" class="<?php if($loop->index == 0) echo 'active' ?>"></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
        <div class="carousel-inner" role="listbox">
            <!-- Slide One - Set the background image for this slide in the line below -->
            <?php $__currentLoopData = $data['slider']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php if($loop->index == 0) echo 'active' ?>" style="background-image: url(<?php echo e($slider->image); ?>)">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12">
                                <!--<div class="carousel-caption d-none d-md-block">-->
                                <div class="carousel-caption d-none d-md-block">
                                    <h2 class="text-uppercase"><?php echo e($slider->title); ?></h2>
                                    <h1><?php echo e($slider->description); ?></h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    
    </section>
    
    <section class="introduction-area">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
              <div class="left-box" style="background: url(<?php echo e($data['sliderbtm']->image); ?>)">
              </div>
          </div>
            <div class="col-sm-6">
                <div class="right-box">
                <h2><?php echo e($data['sliderbtm']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
    
                    <p><?php echo e($data['sliderbtm']->description); ?>

                    </p>
                <a href="<?php echo e(route('about-us.index')); ?>" class="common-button">Read More</a>
                </div>
            </div>
        </div>
      </div>
    </section>
   
    <section class="home-service-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                <h2 class="theme-title"><?php echo e($data['servtop']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
                    <p class="theme-para"><?php echo e($data['servtop']->description); ?> </p>
                </div>
                <?php $__currentLoopData = $data['allservice']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3">
                    <div class="home-service-box">
                        <i class="<?php echo e($service->icon); ?>"></i>
                        <h4><?php echo e($service->title); ?></h4>
                       <p><?php echo e(str_limit($service->description, $limit = 57, $end = ' ')); ?></p>
                        <!--<a href="<?php echo e(route('services.index')); ?>/#<?php echo e($service->link); ?>" class="common-button">Read More</a>-->
                         <a href="<?php echo e(route('service.detailservice',['id' => $service->id])); ?>" class="common-button">Read More</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
    
    <section class="location-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                <h2 class="theme-title"><?php echo e($data['locationtop']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
                    <p class="theme-para"><?php echo e($data['locationtop']->description); ?> </p>
                </div>
    
                <div class="col-sm-12 padding-zero">
                    <div class="location-box-wrap text-center">
                        <?php $__currentLoopData = $data['alllocations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="home-location-box">
                                <!--<i class="fas fa-envelope"></i>-->
                                <h3><?php echo e($locations->title); ?></h3>
                                <p><?php echo e($locations->description); ?></p>
                                <a href="https://goo.gl/maps/fPzAVK3uoqn" target="_blank" class="common-button">Get Direction</a>
                            </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                    </div>
    
                </div>
    
            </div>
        </div>
    </section>
    
    <section class="call-to-action-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="call-to-content">
                        <h2><?php echo e($data['hcall']->description); ?></h2>
                        <a href="#" class="common-button">Learn More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="team-member-area">
            <div class="container">
            <div class="row">
                <div class="col-sm-12">
                <h2 class="theme-title"><?php echo e($data['teamtop']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
                    <p class="theme-para"><?php echo e($data['teamtop']->description); ?> </p>
                    </div>
                    <div class="col-sm-12">
                    <div class="team-wrapper owl-carousel">
                        
                        <?php $__currentLoopData = $data['teammembers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="team-box">
                            <img src="<?php echo e(url($member->image)); ?>" alt="Team">
                           <h4><?php echo e($member->name); ?></h4>
                            <h5><?php echo e($member->designation); ?></h5>
                            <p><?php echo e($member->description); ?></p>
                            <div class="social-media">
                                <ul class="nav">
                                    <li><a href="<?php echo e($member->fb_link); ?>" class="facebook"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="<?php echo e($member->tw_link); ?>" class="twitter"><i class="fab fa-twitter"></i></a></li>
                                   <li><a href="<?php echo e($member->ln_link); ?>" class="linkedin"><i class="fab fa-linkedin-in"></i></a></li>
                                    <li><a href="<?php echo e($member->gp_link); ?>" class="google-plus"><i class="fab fa-google-plus-g"></i></a></li>
                                </ul>
                              </div>
                         </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
               </div>
           </div>
        </div>
    </section>
    <script src="<?php echo e(asset('frontEnd/vendor/jquery/jquery.min.js')); ?>"></script>

    <section class="home-happy-client-area" style="background: url(<?php echo e(asset('frontEnd/img/slider-img/1.jpg')); ?>); background-repeat: no-repeat; background-position: center; background-size: cover; background-attachment: fixed;">
        <div class="container">
            <div class="row">
                    <div class="col-sm-12 all-tag-box-wrapper">
                            <div class="client-left-part">
                                <div class="happy-client-box">
                                    <h4><i class="far fa-handshake"></i></h4>
                                    <h3><span class="counter"><?php echo e($data['counterpart']->experience); ?></span>+</h3>
                                    <p>YEARS OF EXPERIENCE</p>
                                </div>
                                <div class="happy-client-box">
                                    <h4><i class="fas fa-headset"></i></h4>
                                    <h3 class="counter"><?php echo e($data['counterpart']->team); ?></h3>
                                    <p>CLIENT</p>
                                </div>
                                <div class="happy-client-box">
                                    <h4><i class="fas fa-map-marker-alt"></i></h4>
                                    <h3 class="counter"><?php echo e($data['counterpart']->location); ?></h3>
                                    <p>Office Location</p>
                                </div>
                                <div class="happy-client-box">
                                    <h4><i class="fas fa-users"></i></h4>
                                    <h3><span class="counter"><?php echo e($data['counterpart']->employee); ?></span>+</h3>
                                    <p>Employee</p>
                                </div>
                            </div>
                        </div>
            </div>
        </div>
    </section>
    
    <!--<section class="testimonial-area">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-sm-12">-->
    <!--            <h2 class="theme-title"><?php echo e($data['monialtop']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>-->
    <!--                <p class="theme-para"><?php echo e($data['monialtop']->description); ?> </p>-->
    <!--            </div>-->
    <!--            <div class="col-sm-12">-->
    <!--                <div class="testimonial-wrapper owl-carousel">-->
    <!--                    <?php $__currentLoopData = $data['testimonial']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
                            
                       
    <!--                    <div class="testimonial-box">-->
    <!--                        <img src="<?php echo e(url($item->image)); ?>" alt="Team">-->
    <!--                        <div class="testimonial-content">-->
    <!--                            <p> <i class="fas fa-quote-left"></i><?php echo e($item->description); ?><i class="fas fa-quote-right"></i> </p>-->
    <!--                            <h5><?php echo e($item->name); ?></h5></div>-->
    <!--                    </div>-->
    <!--                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
    <!--                    -->
    <!--                </div>-->
    
                    <!--<div class="testimonial_nav">-->
                    <!--<i class="fa fa-angle-left testi_prev"></i>-->
                    <!--<i class="fa fa-angle-right testi_next"></i>-->
                    <!--</div>-->
    
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.frontmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Frontend/home.blade.php ENDPATH**/ ?>