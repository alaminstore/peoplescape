<?php $__env->startSection('cr','active'); ?>
<?php $__env->startSection('title', 'Peoplesscap | Career '); ?>
<?php $__env->startSection('frntcontent'); ?>
<section class="page-banner-area" style="background: url(<?php echo e($data['careerhead']->image); ?>); background-repeat: no-repeat; background-position: center; background-size: cover; background-attachment: fixed;">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <h2 class="page-banner-title"><?php echo e($data['careerhead']->title); ?></h2>
        </div>
      </div>
    </div>
  </section>
   <?php
    //   dd($jobDetail);
    //   exit;
    use Carbon\Carbon;
  ?> 
  <section class="career-page-area">
      <div class="container">
          <div class="row">
              <div class="col-sm-12">
  
              <h3 class="jobs-number-list">Jobs: (<?php echo e($jobDetail->firstItem()); ?> - <?php echo e($jobDetail->lastItem()); ?> out of <?php echo e($jobDetail->total()); ?>)</h3>
  
                  <!--Single Job Post Start-->
                  <?php $__currentLoopData = $jobDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="single-career-box">
                      <h4><?php echo e($item->title); ?> <span><?php echo e($item->company); ?></span> </h4>
                      <div class="career-sub-list">
                          <p><i class="fas fa-business-time"></i>Experience:<span><?php echo e($item->experience); ?></span></p>
                          <p><i class="fas fa-chair"></i>Vacancy:<span><?php echo e($item->vacancy); ?></span></p>
                          <p><i class="fas fa-graduation-cap"></i>Education :<span><?php echo e($item->education); ?></span></p>
                          <p><i class="fas fa-calendar-alt"></i>Deadline :<span><?php echo e($item->deadline); ?></span></p>
                      </div>
  
                      <p class="career-short-des"><?php echo e(str_limit($item->topdescription, 200, '...')); ?>

                      </p>
                    <a href="<?php echo route('career.details',['id'=>$item->id]); ?>" class="common-button">Read More</a>
                      <p class="posted-time">
                      <?php
                       $date = Carbon::parse($item->created_at);
                            $dat_pro =  $date->diffForHumans(Carbon::now());
                           echo $dat_pro;
                         ?>
                         
                        </p>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($jobDetail->links()); ?>


  
                  
  
              </div>
          </div>
      </div>
  </section>
  
  <section class="call-to-action-area">
      <div class="container">
          <div class="row">
              <div class="col-sm-12">
                  <div class="call-to-content">
                      <h2>Amar Sonar Bangla, Ami Tomay Valo</h2>
                      <a href="#" class="common-button">Learn More</a>
                  </div>
              </div>
          </div>
      </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.frontmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Frontend/career.blade.php ENDPATH**/ ?>