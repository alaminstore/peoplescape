<?php $__env->startSection('srv','active'); ?>
<?php $__env->startSection('title', 'Peoplesscap | '.$data['detailservice']->title); ?>
<?php $__env->startSection('frntcontent'); ?>
<section class="page-banner-area" style="background: url(<?php echo e('/'.$data['servicehead']->image); ?>); background-repeat: no-repeat; background-position: center; background-size: cover; background-attachment: fixed;">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h2 class="page-banner-title"><?php echo e($data['detailservice']->title); ?></h2>
            </div>
        </div>
    </div>
</section>

<!-- Services Details Area START -->
<section class="services-details-area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h2 class="theme-title"><?php echo e($data['servicetop']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontend/img/title-style.png')); ?>" alt=""></span></h2>
                <p class="theme-para"><?php echo e($data['servicetop']->description); ?> </p>
            </div>
            
            <div class="col-sm-12 all-s-details">
                <div id="head" class="common-single-s-details">
                    <div class="single-s-details">
                        <div class="single-s-slider-wrapper">
                            <div class="single-s-slider">
                                <!-- Wrapper for slides -->
                                <figure class="item">
                                    <img alt="Services" src="<?php echo e(url($data['detailservice']->image)); ?>">
                                </figure>
                            </div>
                        </div>
                        <div class="single-s-content">
                            <h4><?php echo e($data['detailservice']->title); ?></h4>
                            <p><?php echo e($data['detailservice']->description); ?>

                            </p>
                        </div>
                    </div>
                </div>
                </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.frontmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Frontend/detailservice.blade.php ENDPATH**/ ?>