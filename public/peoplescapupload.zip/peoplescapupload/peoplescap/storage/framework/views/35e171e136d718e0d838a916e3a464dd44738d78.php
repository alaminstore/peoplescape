<?php $__env->startSection('career-active','active'); ?>
<?php $__env->startSection('title', 'Peoplescape | Career|'.$data['careerbyid']->title); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
        <div class="box box-info">
             <div class="box-header with-border">
             <h3 class="box-title">Job Post</h3>
             </div>
             <?php echo Form::open(['route'=>'career.update','class' => 'form-horizontal','id'=>'jobupdate','enctype'=>'multipart/form-data']); ?>

             <div class="box-body">
                 <div class="form-group">
                     <label for="title" class="col-sm-2 control-label">Job Title (2)</label>
                     <div class="col-sm-8">
                     <input type="text" class="form-control" id="title" name="title" value="<?php echo e($data['careerbyid']->title); ?>">
                     <input type="text" class="form-control" id="id" name="id" value="<?php echo e($data['careerbyid']->id); ?>">

                     </div>
                 </div>
                 <div class="form-group">
                    <label for="title" class="col-sm-2 control-label">Company Name (2)</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control" id="company" name="company" value="<?php echo e($data['careerbyid']->company); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="title" class="col-sm-2 control-label">Experience</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control" id="experience" name="experience" value="<?php echo e($data['careerbyid']->experience); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="title" class="col-sm-2 control-label">Vacancy</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control" id="vacancy" name="vacancy" value="<?php echo e($data['careerbyid']->vacancy); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="title" class="col-sm-2 control-label">Education</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control" id="education" name="education" value="<?php echo e($data['careerbyid']->education); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="title" class="col-sm-2 control-label">Deadline</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control" id="deadline" name="deadline" value="<?php echo e($data['careerbyid']->deadline); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="title" class="col-sm-2 control-label">Location</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control" id="location" name="location" value="<?php echo e($data['careerbyid']->location); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="title" class="col-sm-2 control-label">Salary</label>
                    <div class="col-sm-8">
                    <input type="text" class="form-control" id="salary" name="salary" value="<?php echo e($data['careerbyid']->salary); ?>">
                    </div>
                </div>
               
                <div class="form-group">
                    <label for="department"  class="col-sm-2 control-label">Select Category</label>
                    <div class="col-sm-8">
                      <select id="category" class="form-control"  name="catid">
                          <option value="">Select Category</option>
                          <?php $__currentLoopData = $data['cat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($category->id); ?>"<?php if($category->id == $data['careerbyid']->catid): ?> selected = 'selected' <?php endif; ?> ><?php echo e($category->title); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                
                <div class="form-group">
                    <label for="title" class="col-sm-2 control-label">Job Description</label>
                    <div class="col-sm-8">
                    <textarea type="text" class="form-control" id="topdescription" name="topdescription"  rows="8"><?php echo e($data['careerbyid']->topdescription); ?></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label for="title" class="col-sm-2 control-label">Responsibilities Text</label>
                    <div class="col-sm-8">
                    <textarea type="text" class="form-control" id="responsibilitiestext" name="responsibilitiestext"  rows="5"><?php echo e($data['careerbyid']->responsibilitiestext); ?></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <label for="title" class="col-sm-2 control-label">Responsibilities</label>
                    <?php
                      $program = json_decode($data['careerbyid']->responsibilitiespoint);
                    ?>
                <div class="list col-sm-8 " data-index_no="1000">
                    <div class="itemWrapper">
                        <table class="table table-bordered moreTable">
                            <tr>
                                <th width="5%">Serial No</th>
                                <th width="50%">Responsibilities</th>
                                <th width="15%">Option</th>
                            </tr>
                             <?php $__currentLoopData = $program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 
                            
                                <tr class="item_tr single_list">
                                    <td class="day_no"><?php echo e($loop->index +1); ?></td>
                                    <td><input type="text" class="form-control" id="pro_description" name="program[<?php echo e($loop->index +1); ?>][responsibilitiespoint]" value="<?php echo e($item->responsibilitiespoint); ?>" ><br></td>
                                    <td><span class="remove" style="background: #ed3610;padding: 8px 10px;color: #fff;border-radius: 6%;text-decoration: none;cursor:pointer">-</span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <span  class="add_more" style="background: #28d19c;
                                                                padding: 8px 21px;
                                                                color: #fff;
                                                                border-radius: 8%;text-decoration: none; margin-bottom: 10px;cursor:pointer;">+</span><br><br>
                    </div>
                </div>
            </div> 
            <div class="form-group">
                <label for="title" class="col-sm-2 control-label">Qualifications</label>
                <?php
                $qualification = json_decode($data['careerbyid']->qualification);
              ?>
            <div class="slist col-sm-8 " data-index_no="1000">
                <div class="sitemWrapper">
                    <table class="table table-bordered smoreTable">
                        <tr>
                            <th width="5%">Serial No</th>
                            <th width="50%">Qualification</th>
                            <th width="15%">Option</th>
                        </tr>
                        <?php $__currentLoopData = $qualification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quali): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="sitem_tr ssingle_list">
                                <td class="day_no"><?php echo e($loop->index +1); ?></td>
                            <td><input type="text" class="form-control" id="pro_description" name="qualification[<?php echo e($loop->index +1); ?>][qualification]" value="<?php echo e($quali->qualification); ?>" ><br></td>
                                <td><span class="sremove" style="background: #ed3610;padding: 8px 10px;color: #fff;border-radius: 6%;text-decoration: none;cursor:pointer">-</span></td>
                            </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <span  class="sadd_more" style="background: #28d19c;
                                                            padding: 8px 21px;
                                                            color: #fff;
                                                            border-radius: 8%;text-decoration: none; margin-bottom: 10px;cursor:pointer;">+</span><br><br>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">How To Apply Text</label>
            <div class="col-sm-8">
            <textarea type="text" class="form-control" id="howtoapply" name="howtoapply"  rows="5"><?php echo e($data['careerbyid']->howtoapply); ?></textarea>
            </div>
        </div>
             </div>
             <div class="box-footer">
                 <button type="submit" class="btn btn-info">Update</button>
             </div>
             <?php echo Form::close(); ?>

         </div>
     </section>
     <script>
                $(document).on('click', '.sadd_more', function () {
                        var index = $('.slist').data('index_no');
                        $('.slist').data('index_no', index + 1);
                        var html = $('.sitemWrapper .sitem_tr:last').clone().find('.form-control').each(function () {
                            this.name = this.name.replace(/\d+/, index+1);
                            this.id = this.id.replace(/\d+/, index+1);
                            this.value = '';
                        }).end();
                        $('.smoreTable').append(html);
                        var rowCount = $('.smoreTable tr').length;
                        $(this).closest('.sitemWrapper').find('.sitem_tr:last').find('.day_no').html(rowCount-1);
                        $(this).closest('.sitemWrapper').find('.sitem_tr:last').find('.dayval').val(rowCount-1);
                    });
                    $(document).on('click', '.sremove', function () {
                        var obj=$(this);
                        var count= $('.ssingle_list').length;
                        // alert(count);
                        if(count > 1) {
                            if(obj.closest('.ssingle_list').is($(this).closest('.sitemWrapper').find('.ssingle_list:last'))){
                                obj.closest('.ssingle_list').remove();
                            }else{
                                alert('You can only remove the last one!');
                            }
                        }
                    });
                    $(document).on('click', '.add_more', function () {
                        var index = $('.list').data('index_no');
                        $('.list').data('index_no', index + 1);
                        var html = $('.itemWrapper .item_tr:last').clone().find('.form-control').each(function () {
                            this.name = this.name.replace(/\d+/, index+1);
                            this.id = this.id.replace(/\d+/, index+1);
                            this.value = '';
                        }).end();
                        $('.moreTable').append(html);
                        var rowCount = $('.moreTable tr').length;
                        $(this).closest('.itemWrapper').find('.item_tr:last').find('.day_no').html(rowCount-1);
                        $(this).closest('.itemWrapper').find('.item_tr:last').find('.dayval').val(rowCount-1);
                    });
                    $(document).on('click', '.remove', function () {
                        var obj=$(this);
                        var count= $('.single_list').length;
                        // alert(count);
                        if(count > 1) {
                            if(obj.closest('.single_list').is($(this).closest('.itemWrapper').find('.single_list:last'))){
                                obj.closest('.single_list').remove();
                            }else{
                                alert('You can only remove the last one!');
                            }
                        }
                    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.backendmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Backend/career/editcareer.blade.php ENDPATH**/ ?>