<?php echo $__env->make('Frontend.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
  <?php echo $__env->make('Frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->yieldContent('frntcontent'); ?>

<?php echo $__env->make('Frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Bootstrap core JavaScript -->

<!--<script src="vendor/jquery/jquery.slim.min.js"></script>-->


<script src="<?php echo e(asset('frontEnd/vendor/jquery/jquery.proper.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontEnd/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>

<!-- Plugin JavaScript -->
<script src="<?php echo e(asset('frontEnd/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontEnd/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- =====jQuery Waypoints==== -->
<script src="<?php echo e(asset('frontEnd/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontEnd/js/jquery.counterup.min.js')); ?>"></script>

<!-- Custom scripts for this template -->
<script src="<?php echo e(asset('frontEnd/js/active.js')); ?>"></script>

</body>

</html>
<?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Frontend/frontmaster.blade.php ENDPATH**/ ?>