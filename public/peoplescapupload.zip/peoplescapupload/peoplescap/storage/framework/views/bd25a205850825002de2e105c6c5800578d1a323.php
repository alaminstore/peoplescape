<?php $__env->startSection('cl','active'); ?>
<?php $__env->startSection('title', 'Peoplesscap | Client '); ?>
<?php $__env->startSection('frntcontent'); ?>
<section class="page-banner-area" style="background: url(<?php echo e($data['clienthead']->image); ?>); background-repeat: no-repeat; background-position: center; background-size: cover; background-attachment: fixed;">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <h2 class="page-banner-title"><?php echo e($data['clienthead']->title); ?></h2>
        </div>
      </div>
    </div>
  </section>
  
  <section class="client-logo-area">
      <div class="container">
          <div class="row">
              <div class="col-sm-12">
              <h2 class="theme-title"><?php echo e($data['clienttop']->title); ?> <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
              <p class="theme-para"><?php echo e($data['clienttop']->description); ?></p>
              </div>
              <div class="col-sm-12">
                  <?php $__currentLoopData = $data['clients']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="client-logo">
                      <a href="<?php echo e($client->url); ?>"><img src="<?php echo e(url($client->image)); ?>" alt="GP"></a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
              </div>
          </div>
      </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.frontmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Frontend/client.blade.php ENDPATH**/ ?>