<?php $__env->startSection('gl','active'); ?>
<?php $__env->startSection('title', 'Peoplesscap | Galary '); ?>
<?php $__env->startSection('frntcontent'); ?>
<section class="page-banner-area" style="background: url(<?php echo e($data['contacthead']->image); ?>); background-repeat: no-repeat; background-position: center; background-size: cover; background-attachment: fixed;">
        <div class="container">
          <div class="row">
            <div class="col-sm-12">
              <h2 class="page-banner-title">Image Gallery</h2>
            </div>
          </div>
        </div>
    </section>
    <style>
        
    </style>
    <section class="client-logo-area slider-area carousel slide" id="carouselExampleIndicators" data-ride="">
            <div class="container">
              <div class="row">
                <div class="col-sm-12">
                <h2 class="theme-title" style="margin-top: 50px; margin-bottom: 45px">Gallery <span class="title-img-style"><img src="<?php echo e(asset('frontEnd/img/title-style.png')); ?>" alt=""></span></h2>
                </div>
                <div class="col-sm-12">
            
            <div class="carousel-inner" style="margin-bottom:30px" role="listbox">
                <!-- Slide One - Set the background image for this slide in the line below -->
                <?php $__currentLoopData = $data['slider']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="diprnt carousel-item <?php if($loop->index == 0) echo 'active' ?>" style="background-image: url(<?php echo e($slider->image); ?>)">
                        <div class="overlay"><?php echo e($slider->caption); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
                </div>
        </div>
    </div>
</section>  
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.frontmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Frontend/galary.blade.php ENDPATH**/ ?>