<?php $__env->startSection('application-active','active'); ?>
<?php $__env->startSection('title', 'Peoplescape | Application Lists'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box box-info">
          <div class="box-header">
            <h3 class="box-title">Applicant Details Information</h3>
             <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
              </div>
             </div>
          <div class="box-body">
            <table class="table table-bordered table-striped">
                    <tr>
                        <td width="40%"><b>Name</b></td>
                        <td width="60%"><?php echo e($careerInfoByid->name); ?></td>
                    </tr>
                    <tr>
                        <td width="40%"><b>Email</b></td>
                        <td width="60%"><?php echo e($careerInfoByid->email); ?></td>
                    </tr>
                    <tr>
                        <td width="40%"><b>Mobile</b></td>
                        <td width="60%"><?php echo e($careerInfoByid->mobile); ?></td>
                    </tr>
                    <tr>
                        <td width="40%"><b>Home Address</b></td>
                        <td width="60%"><?php echo e($careerInfoByid->haddress); ?></td>
                    </tr>
                    <tr>
                        <td width="40%"><b>Permanent Address</b></td>
                        <td width="60%"><?php echo e($careerInfoByid->paddress); ?></td>
                    </tr>
                    
            </table><br>
           
             <div class="row" style="margin:2px;">
                    <div class="col-12">
                        <div class="form-group">
                        <label for="sel1"><b>Accademic Information</b></label>
                        </div>
                    </div>
             </div>
             <table class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th width="25%">University</th>
                    <th width="25%">Degree</th>
                    <th width="25%">Score</th> 
                </tr>
                </thead>
                <tbody>
                    <?php 
                    if(!empty($careerInfoByid->academic)){
                        $jsonaccdata = json_decode($careerInfoByid->academic);
                    }
                    ?>
                    
                    <?php $__currentLoopData = $jsonaccdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($acc->instname); ?></td>
                    <td><?php echo e($acc->degree); ?></td>
                    <td><?php echo e($acc->cgpa); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table><br>
      
      <div class="row" style="margin:2px;">
        <div class="col-12">
            <div class="form-group">
            <label for="sel1"><b>Work Experience In Details</b></label>
            </div>
        </div>
   </div>
   <table class="table table-bordered table-striped">
      <thead>
      <tr>
          <th width="20%">Job Title</th>
          <th width="20%">Company Name</th>
          <th width="20%">Responsibilities</th> 
          <th width="20%">Joined In</th> 
          <th width="20%">Left In</th> 
      </tr>
      </thead>
      <tbody>
          <?php 
          if(!empty($careerInfoByid->experience)){
              $jsonexpdata = json_decode($careerInfoByid->experience);
          }
          ?>
          
          <?php $__currentLoopData = $jsonexpdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
          <td><?php echo e($exp->title); ?></td>
          <td><?php echo e($exp->company); ?></td>
          <td><?php echo e($exp->responsibilites); ?></td>
          <td><?php echo e($exp->joinedin); ?></td>
          <td><?php echo e($exp->leftin); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table><br>
  <div class="row" style="margin:2px;">
    <div class="col-12">
        <div class="form-group">
        <label for="sel1"><b>Project Info</b></label>
        </div>
    </div>
    </div>
      <table class="table table-bordered table-striped">
          <thead>
          <tr>
              <th width="40%">URL</th>
              <th width="60%">Details</th>
          </tr>
          </thead>
          <tbody>
              <?php 
              if(!empty($careerInfoByid->project)){
                  $jsonprojectdata = json_decode($careerInfoByid->project);
              }
              ?>
              
              <?php $__currentLoopData = $jsonprojectdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td><?php echo e($pro->url); ?></td>
              <td><?php echo e($pro->comment); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
         </table><br>
         <div class="row" style="margin:2px;">
            <div class="col-12">
                <div class="form-group">
                <label for="sel1"><b>Coverletter</b></label>
                
                <textarea name="coverletter" class="form-control" rows="8"><?php echo e($careerInfoByid->interest); ?></textarea>
                </div>
            </div>
     </div>
         <?php if($careerInfoByid->cv): ?>
         <div class="row" style="margin:2px;">
          <div class="col-12">
              <div class="form-group">
              <label for="sel1"><b>Download CV</b></label>
              <a href="<?php echo e(url('/'.$careerInfoByid->cv)); ?>"> Download</a>
            </div>
          </div>
          </div>
          <?php endif; ?>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.backendmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Software\myxampp\htdocs\peoplescap\resources\views/Backend/application/singleapplication.blade.php ENDPATH**/ ?>