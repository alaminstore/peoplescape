<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Servicetop extends Model
{
    //
}
