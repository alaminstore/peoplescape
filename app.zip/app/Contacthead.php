<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contacthead extends Model
{
    //
}
