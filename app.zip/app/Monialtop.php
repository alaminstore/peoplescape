<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Monialtop extends Model
{
    //
}
