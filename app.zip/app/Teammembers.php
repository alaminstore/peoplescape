<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teammembers extends Model
{
    //
}
