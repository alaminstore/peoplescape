<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Alllocations extends Model
{
    //
}
