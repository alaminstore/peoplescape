<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jobapplied extends Model
{
    public $timestamps = false;
}
