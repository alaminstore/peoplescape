<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contactdet extends Model
{
    //
}
